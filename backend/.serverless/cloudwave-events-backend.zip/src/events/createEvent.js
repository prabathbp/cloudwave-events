const mongoose = require("mongoose");
const { v4: uuidv4 } = require("uuid");
const { connectDB } = require("../utils/db");

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS"
};

const eventSchema = new mongoose.Schema({
  eventId: String,
  title: String,
  description: String,
  dateTime: String,
  mediaUrl: String,
  createdAt: String
});

const Event = mongoose.models.Event || mongoose.model("Event", eventSchema);

module.exports.handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: corsHeaders, body: "" };
  }

  try {
    await connectDB();
    const body = JSON.parse(event.body);
    const newEvent = await Event.create({
      eventId: uuidv4(),
      title: body.title,
      description: body.description,
      dateTime: body.dateTime,
      mediaUrl: body.mediaUrl || "",
      createdAt: new Date().toISOString()
    });
    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify(newEvent)
    };
  } catch (error) {
    console.log("createEvent error:", error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message })
    };
  }
};
